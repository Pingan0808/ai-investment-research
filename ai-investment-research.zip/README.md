# 🤖 AI Investment Research System

基于**多 Agent 协作**的智能投研报告生成系统。

[![Python](https://img.shields.io/badge/Python-3.8%2B-blue)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.28%2B-ff4b4b)](https://streamlit.io/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

> 💡 将传统 **8 小时** 的人工投研工作压缩至 **3 分钟** 完成

---

## 📋 目录

- [项目背景](#-项目背景)
- [系统架构](#-系统架构)
- [核心特性](#-核心特性)
- [快速开始](#-快速开始)
- [使用指南](#-使用指南)
- [技术栈](#-技术栈)
- [项目结构](#-项目结构)
- [效果展示](#-效果展示)
- [未来规划](#-未来规划)
- [许可证](#-许可证)

---

## 🎯 项目背景

传统投研工作面临三大痛点：

1. **信息整合效率低** — 分析师需手动检索财报、公告、新闻等多源信息，平均耗时 8 小时以上
2. **分析深度不足** — 复杂财务指标的关联分析依赖个人经验，容易遗漏关键信号
3. **报告质量参差** — 不同分析师的产出标准不一，难以保证一致性

本系统通过 **4 个专业 Agent 协作**，实现投研全流程自动化。

---

## 🏗️ 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    智能投研报告生成系统                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │ 数据采集    │  │ 财务分析    │  │ 舆情分析    │        │
│  │ Agent       │  │ Agent       │  │ Agent       │        │
│  │             │  │ (长链推理)  │  │ (NLP情感)   │        │
│  │ • 行情数据  │  │             │  │             │        │
│  │ • 财务报表  │  │ • 指标计算  │  │ • 情感分类  │        │
│  │ • 新闻舆情  │  │ • 趋势预测  │  │ • 热点识别  │        │
│  │ • 同业对比  │  │ • 风险识别  │  │ • 情绪指数  │        │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘        │
│         │                │                │               │
│         └────────────────┼────────────────┘               │
│                          ▼                                │
│                 ┌─────────────────┐                       │
│                 │   报告撰写 Agent │                       │
│                 │                 │                       │
│                 │ • 结构整合      │                       │
│                 │ • 投资建议生成  │                       │
│                 │ • 可视化图表    │                       │
│                 └─────────────────┘                       │
│                          │                                │
│                          ▼                                │
│                 ┌─────────────────┐                       │
│                 │   结构化报告     │                       │
│                 │   PDF/Word      │                       │
│                 └─────────────────┘                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Agent 协作流程

```mermaid
graph LR
    A[数据采集 Agent<br/>多源并行采集] --> B[财务分析 Agent<br/>长链推理]
    A --> C[舆情分析 Agent<br/>NLP情感分析]
    B --> D[报告撰写 Agent<br/>结构化输出]
    C --> D
```

---

## ✨ 核心特性

| 特性 | 说明 |
|------|------|
| 🤖 **多 Agent 协作** | 4 个专业 Agent 各司其职，并行/串行高效协作 |
| 🧠 **长链推理可视化** | 财务分析 Agent 的推理步骤完全透明，可追溯 |
| 📊 **实时数据模拟** | 基于随机种子生成一致的模拟数据，便于演示 |
| 📈 **交互式图表** | Plotly 驱动的可交互财务图表（K线、雷达图、仪表盘） |
| 💭 **情感仪表盘** | 实时市场情绪可视化，直观展示多空力量 |
| ⚡ **极速生成** | 单份报告从 8 小时压缩至 3 分钟 |

---

## 🚀 快速开始

### 环境要求

- Python 3.8+
- pip

### 安装依赖

```bash
# 克隆仓库
git clone https://github.com/Pingan0808/ai-investment-research.git
cd ai-investment-research

# 创建虚拟环境（推荐）
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或 venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 启动应用

```bash
streamlit run app.py
```

应用将在浏览器中自动打开（默认地址：`http://localhost:8501`）

---

## 📖 使用指南

### 1. 输入股票代码

在左侧输入框中输入股票代码（如 `DEMO`、`AAPL`、`TSLA` 等），系统会基于该代码生成一致的模拟数据。

### 2. 选择分析深度

- **快速**：基础财务指标 + 简要舆情
- **标准**：完整财务分析 + 舆情监测 + 同业对比
- **深度**：增加趋势预测、风险传导分析

### 3. 查看报告

系统自动执行 4 个 Agent，生成包含以下内容的结构化报告：

- 📊 **核心图表**：K线图、营收趋势、同业对比雷达图
- 💰 **财务分析**：关键指标卡片、风险信号、完整财务报表
- 📰 **舆情监测**：情感仪表盘、热点话题、相关新闻
- 🤖 **Agent 工作流**：各 Agent 推理链可视化、协作流程图

### 4. 导出报告

点击「导出 PDF 报告」按钮，可将报告保存为 PDF 格式（需额外配置）。

---

## 🛠️ 技术栈

| 类别 | 技术 |
|------|------|
| **前端框架** | Streamlit |
| **可视化** | Plotly |
| **数据处理** | Pandas, NumPy |
| **数据模型** | Python Dataclasses |
| **版本控制** | Git |

---

## 📁 项目结构

```
ai-investment-research/
├── 📄 app.py                    # 主应用入口
├── 📄 requirements.txt          # 依赖列表
├── 📄 README.md                 # 项目说明
├── 📄 LICENSE                   # MIT 许可证
│
├── 📁 agents/                   # Agent 模块
│   ├── __init__.py
│   ├── data_collection.py       # 数据采集 Agent
│   ├── financial_analysis.py    # 财务分析 Agent
│   ├── sentiment_analysis.py    # 舆情分析 Agent
│   └── report_generation.py     # 报告撰写 Agent
│
├── 📁 utils/                    # 工具模块
│   ├── __init__.py
│   ├── data_generator.py        # 模拟数据生成器
│   └── visualizations.py        # 图表渲染组件
│
├── 📁 data/                     # 数据目录（运行时生成）
│   └── .gitkeep
│
└── 📁 assets/                   # 静态资源
    └── .gitkeep
```

---

## 🖼️ 效果展示

### 主界面

![主界面](assets/screenshot_main.png)

### 财务分析

![财务分析](assets/screenshot_financial.png)

### Agent 工作流

![Agent工作流](assets/screenshot_agents.png)

---

## 🔮 未来规划

- [ ] 接入真实金融数据 API（Tushare、AkShare、Yahoo Finance）
- [ ] 支持多语言报告生成（中英文切换）
- [ ] 增加估值模型 Agent（DCF、PE、PB 估值）
- [ ] 集成 LLM 进行自然语言报告生成
- [ ] 支持 PDF/Word 一键导出
- [ ] 添加用户权限管理和报告历史记录

---

## 🤝 贡献指南

欢迎提交 Issue 和 Pull Request！

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开 Pull Request

---

## 📄 许可证

本项目采用 [MIT](LICENSE) 许可证开源。

---

## 👤 作者

**Pingan0808**

- GitHub: [@Pingan0808](https://github.com/Pingan0808)

---

> ⭐ 如果这个项目对你有帮助，请给它一个 Star！
